﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Porta : MonoBehaviour
{
    public SpriteRenderer PortaA;
    public SpriteRenderer PortaF;
    public BoxCollider2D CorpoPA;
    public BoxCollider2D CorpoPF;
    public int chave;
    // Start is called before the first frame update
    void Start()
    {
        PortaA = GameObject.Find("Portapart2").GetComponent<SpriteRenderer>();
        CorpoPA = GameObject.Find("Portapart2").GetComponent<BoxCollider2D>();
        PortaF = GameObject.Find("Portapart1").GetComponent<SpriteRenderer>();
        CorpoPF = GameObject.Find("Portapart1").GetComponent<BoxCollider2D>();
    }

    // Update is called once per frame
    void Update()
    {

        void OnCollisionEnter2D(Collision2D otherObj)
        {
            if (otherObj.gameObject.tag == "PORCO")
            {
                PortaA.enabled = true;
                CorpoPA.enabled = true;
                PortaF.enabled = false;
                CorpoPF.enabled = false;
            }
        }
    }
}
