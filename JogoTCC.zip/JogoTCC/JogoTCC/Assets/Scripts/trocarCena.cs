﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
public class trocarCena : MonoBehaviour
{
private string Nome;
bool isPause;
    void Pause()
    {
        Time.timeScale = 0;
    }
    void UnPause(){
        Time.timeScale = 1;
    }
    
    // Start is called before the first frame update
    void Start()
    {
        Nome = SceneManager.GetActiveScene().name;
    }

    // Update is called once per frame
    public void Cena(string chave){
            switch (chave)
        {
            case "Jogar":
            SceneManager.LoadScene("primeira fase");
            break;
            case "Continuar":
            SceneManager.LoadScene("");
            break;
            case "Opcoes":
            SceneManager.LoadScene("Opcoes");
            break;
            case "Sair":
            Application.Quit();
            break;
            case "Voltar":
            SceneManager.LoadScene("SampleScene");
            UnPause();
            break;       
        }
    }
}