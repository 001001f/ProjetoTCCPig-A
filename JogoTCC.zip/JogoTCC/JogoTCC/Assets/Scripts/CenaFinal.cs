﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CenaFinal : MonoBehaviour
{
    public SpriteRenderer Cenario;
    public SpriteRenderer cFinal;
    // Start is called before the first frame update
    void Start()
    {
        Cenario = GameObject.Find("preto").GetComponent<SpriteRenderer>();
        cFinal = GameObject.Find("cenafinal").GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void OnCollisionEnter2D(Collision2D otherObj)
    {
        if (otherObj.gameObject.tag == "PORCO")
        {
            Cenario.enabled = true;
            cFinal.enabled = true;
        }
    }
}
