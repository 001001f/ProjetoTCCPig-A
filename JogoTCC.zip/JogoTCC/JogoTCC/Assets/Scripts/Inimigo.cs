﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Inimigo : MonoBehaviour
{

    private Transform target;
    public Rigidbody2D movimentoInimigo;
    public SpriteRenderer render;
    public Animator Parado;
    public Animator Correndo;
    private bool Paradon = false;
    private bool Correndon = false;
    public Vector3 velocidade;
    public bool olhandoParaDireita;

    void Start()
    {
        //pegar porco:target = GameObject.FindGameObjectWithTag("PORCO").GetComponent<Transform>(); 
        Parado = GetComponent<Animator>();
        render = GetComponent<SpriteRenderer>();
        Correndo = GetComponent<Animator>();
        velocidade = new Vector3(0.03f, 0);
        olhandoParaDireita = true;
    }

    // Update is called once per frame
    void Update()
    {
        //transform.position = Vector2.MoveTowards(transform.position, target.position,Speed*Time.deltaTime);
        //    if(target.position.x > transform.position.x){
        //    render.flipX = false;
        //}else{
        //render.flipX = true;
        //}
        //caminhar automático :
        this.transform.position += velocidade;
        
        movimentarI();
    }
    void movimentarI()
    {
        if (movimentoInimigo.velocity.x == 0 && movimentoInimigo.velocity.y == 0)
        {
            Paradon = true;
            Correndon = false;
        }
        if (movimentoInimigo.velocity.x != 0 && movimentoInimigo.velocity.y != 0 ||
          movimentoInimigo.velocity.x != 0 || movimentoInimigo.velocity.y == 0 ||
          movimentoInimigo.velocity.x == 0 || movimentoInimigo.velocity.y != 0)
        {
            Paradon = false;
            Correndon = true;
        }
        Parado.SetBool("Parado", Paradon);
        Correndo.SetBool("Correndo", Correndon);
    }
    /*void OnCollisionEnter2D (Collision2D other) {
      if (other.gameObject.tag == "PAREDE") {
        velocidade.x = velocidade.x * -1;
        if (olhandoParaDireita == true) {
          transform.eulerAngles = new Vector3 (0, -180, 0);
          olhandoParaDireita = false;
        } else {
          transform.eulerAngles = new Vector3 (0, 0, 0);
          olhandoParaDireita = true;
        }
      }
    }*/
}