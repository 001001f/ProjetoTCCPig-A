﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Inimigo : MonoBehaviour
{

    private Transform target;
    public Rigidbody2D movimentoInimigo;
    public SpriteRenderer render;    
    public Animator Correndo;

    private bool Correndon = false;
    public Vector3 velocidade;
    public bool olhandoParaDireita;

    //teste
    public Rigidbody2D rigid;
    public float Speed = 5;
    public float StoppingDistance;
    public Animator Cade;
    private bool Caden = false;
    private caixa caixa;
    private bool perseguindo;
    private Transform Target;

    void Start()
    {
        //pegar porco:target = GameObject.FindGameObjectWithTag("PORCO").GetComponent<Transform>(); 
        
        render = GetComponent<SpriteRenderer>();
        Correndo = GetComponent<Animator>();
        velocidade = new Vector3(0.04f, 0);
        olhandoParaDireita = true;

        //teste
        Target = GameObject.FindGameObjectWithTag("PORCO").GetComponent<Transform>();
        //Cade = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        //teste
        if (Vector2.Distance(transform.position, Target.position) < StoppingDistance)
        {
            transform.position = Vector2.MoveTowards(transform.position, Target.position, Speed * Time.deltaTime);
            velocidade = new Vector3(0.05f, 0, 52);
        }
        

            /*
            if (Vector2.Distance(transform.position, target.position) < 2)
            {
                transform.position = Vector2.MoveTowards(transform.position, target.position, Speed * Time.deltaTime);
                if (target.position.x > transform.position.x)
                {
                    render.flipX = false;
                }
                else
                {
                    render.flipX = true;
                }
            }*/
            //caminhar automático :
            this.transform.position += velocidade;
        
        movimentarI();
    }
    void movimentarI()
    {
       
        
        if (movimentoInimigo.velocity.x != 0 && movimentoInimigo.velocity.y != 0 ||
          movimentoInimigo.velocity.x != 0 || movimentoInimigo.velocity.y == 0 ||
          movimentoInimigo.velocity.x == 0 || movimentoInimigo.velocity.y != 0)
        {
           
            Correndon = true;
        }
        Correndo.SetBool("Correndo", Correndon);

    }
    void OnCollisionEnter2D (Collision2D other) {
      if (other.gameObject.tag == "PAREDE") {
        velocidade.x = velocidade.x * -1;
        if (olhandoParaDireita == true) {
          transform.eulerAngles = new Vector3 (0, -180, 0);
          olhandoParaDireita = false;
        } else {
          transform.eulerAngles = new Vector3 (0, 0, 0);
          olhandoParaDireita = true;
        }
      }
    }
}