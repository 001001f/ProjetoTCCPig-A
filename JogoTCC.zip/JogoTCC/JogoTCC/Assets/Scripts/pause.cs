﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class pause : MonoBehaviour
{
    public Image botao1, botao2;
    public SpriteRenderer Menu;
    bool isPause;
    // Start is called before the first frame update
    void Start() {
        Menu = GameObject.Find("pausafinalizado (2)").GetComponent<SpriteRenderer>();

        botao1 = GameObject.Find("Menu").GetComponent<Image>();
        botao2 = GameObject.Find("Voltar").GetComponent<Image>();
    }
    void Pause()
    {   
        Time.timeScale = 0;

    }
    void UnPause(){
        Time.timeScale = 1;
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.P) || Input.GetKeyDown(KeyCode.Escape)){
                isPause = !isPause;

                if(isPause){
                    Menu.enabled = true;
                    botao1.enabled = true;
                    botao2.enabled = true;
                    Pause ();
                }else{
                   
                    Menu.enabled = false;
                    botao1.enabled = false;
                    botao2.enabled = false; 
                    UnPause();
                }
        }
    }
    public void Cena(string chave){
            switch (chave)
        {
            case "Pausar":
            isPause = !isPause;
                if(isPause){
                    Pause ();
                    Menu.enabled = true;
                    botao1.enabled = true;
                    botao2.enabled = true;
                }else
                {
                    UnPause();
                    Menu.enabled = false;
                    botao1.enabled = false;
                    botao2.enabled = false;
                }
                break;
            case "Voltaraojogo":
            isPause = !isPause;
                if(isPause)
                {
                    Menu.enabled = false;
                    botao1.enabled = false;
                    botao2.enabled = false;
                    UnPause();
                }
                break;
        }
    }
}