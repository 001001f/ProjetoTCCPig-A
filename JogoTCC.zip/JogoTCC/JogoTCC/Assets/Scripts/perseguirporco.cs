﻿using UnityEngine;

public class perseguirporco : MonoBehaviour
{
    public Transform m_Player;
    public float m_Velocidade;

    // Update is called once per frame
    void Update()
    {
        float distancia = Vector2.Distance(transform.position, m_Player.position);
        if(distancia>1 && distancia < 3)
        {
            transform.position = Vector2.MoveTowards(transform.position, m_Player.position, m_Velocidade * Time.deltaTime);
        }
    }
}