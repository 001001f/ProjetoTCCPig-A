﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class caixa : MonoBehaviour
{ 
    public SpriteRenderer render;
    public Rigidbody2D rigid;
    public SpriteRenderer PorcoDentro;
    public SpriteRenderer CaixaFora;
    public SpriteRenderer PorcoD;
    public BoxCollider2D CorpoP;
    public BoxCollider2D CorpoC;
    public movimentacao movi;
    public JogadorInterage EstaInteragindo;
    public bool entrou = false;

    // Start is called before the first frame update
    void Start()
    {

        render = GetComponent<SpriteRenderer>();
        
        PorcoDentro = GameObject.Find("Porconacaixa").GetComponent<SpriteRenderer>();
        CaixaFora = GameObject.Find("caixaparaporco").GetComponent<SpriteRenderer>();
        PorcoD = GameObject.Find("Dipsy").GetComponent<SpriteRenderer>();
        movi = GameObject.Find("Dipsy").GetComponent<movimentacao>();
        CorpoP = GameObject.Find("Dipsy").GetComponent<BoxCollider2D>();
        CorpoC = GameObject.Find("Porconacaixa").GetComponent<BoxCollider2D>();
       
        //movimentoI.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezePositionY;
        //rigid.constraints = RigidbodyConstraints2D.FreezeAll;
        
    }
    public void caixadodipsy(){
        if(EstaInteragindo == true)
        {
            PorcoDentro.enabled = true;
            CaixaFora.enabled = false;
            PorcoD.enabled = false;
            movi.enabled = false;
            CorpoP.enabled = false;
            CorpoC.enabled = true;
            entrou = true;
           rigid.constraints = RigidbodyConstraints2D.FreezePosition | RigidbodyConstraints2D.FreezeRotation;
        }
        
    }
    void Update(){
        if(entrou==true && Input.GetKey(KeyCode.O))
        {
            PorcoDentro.enabled = false;
            CaixaFora.enabled = true;
            PorcoD.enabled = true;
            movi.enabled = true;
            CorpoP.enabled = true;
            CorpoC.enabled = false;
            rigid.constraints = RigidbodyConstraints2D.FreezeRotation;
            entrou = false;
        }
}
    
}