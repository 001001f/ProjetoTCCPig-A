﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class movimentacao : MonoBehaviour
{
    private float velocidadeAndar=5;
    public Rigidbody2D movimento;
    public int vida;
    public int chave=0;
    public Animator Parado, Correndo;
    private bool Paradon=false, Correndon=false;
    public SpriteRenderer vira;
    // Start is called before the first frame update
    void Start()
    {
        vida = 3;
        vira = GetComponent<SpriteRenderer>();
        
         Parado = GetComponent<Animator>();
         Correndo = GetComponent<Animator>();
        movimento = GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void Update()
    {
        
        movimento.velocity = new Vector2(Input.GetAxis("Vertical")*velocidadeAndar, movimento.velocity.y);
        movimento.velocity = new Vector2(Input.GetAxis("Horizontal")*velocidadeAndar, movimento.velocity.x);
        MovimentoD();

        if(movimento.velocity.x == 0 && movimento.velocity.y == 0){
            Paradon = true;        
        }
        if(movimento.velocity.x == 7 && movimento.velocity.y == 7){
            Correndon = true;      
        }
        if(movimento.velocity.x != 0 && movimento.velocity.y != 0 || movimento.velocity.x != 0 && movimento.velocity.y == 0 || movimento.velocity.x == 0 && movimento.velocity.y != 0){
            Paradon = false;      
        }
        if(movimento.velocity.x != 7 && movimento.velocity.y != 7 || movimento.velocity.x != 7 && movimento.velocity.y == 7 || movimento.velocity.x == 7 && movimento.velocity.y != 7){
            Correndon = false;     
        }       
        Parado.SetBool("Parado",Paradon);
        Correndo.SetBool("Correndo", Correndon);  

        
        
        
    }
    void OnCollisionEnter2D(Collision2D otherObj) {
        if (otherObj.gameObject.tag == "CHAVE") {
            Destroy(otherObj.gameObject);
            chave=+1; 
        }  
        if (otherObj.gameObject.tag == "PORTA" && chave == 1) {
            SceneManager.LoadScene("segunda fase");
        }
    }
    void MovimentoD(){
        if(Input.GetKeyDown(KeyCode.A)){
            vira.flipX = true;
        }
        if(Input.GetKey(KeyCode.Space)){
            velocidadeAndar = 10;            
        }
        else{velocidadeAndar=5;}
        if(Input.GetKeyDown(KeyCode.D)){
            vira.flipX = false;
        }
        if(Input.GetKey(KeyCode.Space)){
            velocidadeAndar = 9;                
        }
        else{velocidadeAndar=5;}
        
    }
    

}