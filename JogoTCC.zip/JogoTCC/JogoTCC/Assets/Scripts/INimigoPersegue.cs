﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class INimigoPersegue : MonoBehaviour
{
    public float Speed=5;
    public float StoppingDistance;
    private Transform target;
    public Transform voltaPraLaFiedamae;
    public Animator Cade;
    private bool Caden = false;
    private caixa caixa;
    private bool perseguindo;
    public Vector3 velocidade;

    public Animator Correndo;

    private bool Correndon = false;

    // Start is called before the first frame update
    void Start()
    {
        Correndo = GetComponent<Animator>();



        target = GameObject.FindGameObjectWithTag("PORCO").GetComponent<Transform>();
        caixa = FindObjectOfType(typeof(caixa)) as caixa;
    }
    // Update is called once per frame
    void Update()
    {        if (Vector2.Distance(transform.position, target.position) < StoppingDistance)

        {
            perseguindo = true;

        }else if (Vector2.Distance(transform.position, target.position) > StoppingDistance)
        {
            perseguindo = false;
            Correndon = true;
        }
        if (perseguindo && !caixa.entrou)
        {
            StoppingDistance = 4;
            transform.position = Vector2.MoveTowards(transform.position, target.position, Speed * Time.deltaTime);
            Correndon = true;
        }
        else if (!perseguindo)
        {
            //teste
            this.transform.position += velocidade;
            Correndon = true;
        }Correndo.SetBool("Correndo", Correndon);

    }
	/*void gambiarra(){
		if(Caden = false){
			target = GameObject.FindGameObjectWithTag("PORCO").GetComponent<Transform>();
			if (Vector2.Distance(transform.position, target.position) < StoppingDistance)

        {
            transform.position = Vector2.MoveTowards(transform.position, target.position, Speed * Time.deltaTime);
        }
    }
		}*/
	
	void OnCollisionEnter2D(Collision2D other)
    {
	/*if (perseguindo) {
        StoppingDistance = 5;
	    }
        else if(!perseguindo)
        {
            StoppingDistance = 0;
        }*/
    }
}
