﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class INimigoPersegue : MonoBehaviour
{
    public float Speed=5;
    public float StoppingDistance;
    private Transform target;
    public Animator Cade;
    private bool Caden = false;

    // Start is called before the first frame update
    void Start()
    {
	    target = GameObject.FindGameObjectWithTag("PORCO").GetComponent<Transform>();
    }
    // Update is called once per frame
    void Update()
    {        if (Vector2.Distance(transform.position, target.position) < StoppingDistance)

        {
            transform.position = Vector2.MoveTowards(transform.position, target.position, Speed * Time.deltaTime);
        }
    }
	/*void gambiarra(){
		if(Caden = false){
			target = GameObject.FindGameObjectWithTag("PORCO").GetComponent<Transform>();
			if (Vector2.Distance(transform.position, target.position) < StoppingDistance)

        {
            transform.position = Vector2.MoveTowards(transform.position, target.position, Speed * Time.deltaTime);
        }
    }
		}*/
	
	void OnCollisionEnter2D(Collision2D other)
    {
	if (other.gameObject.tag == "PORCONACAIXA") {
        StoppingDistance = 0;
        Caden = true;
            return;
	}
	Cade.SetBool("Cade",Caden);
	}
    
}
